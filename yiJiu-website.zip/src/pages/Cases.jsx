import PageHeader from '../components/PageHeader'
import AnimatedSection from '../components/AnimatedSection'

const clients = [
  '恒力集团', 'CSSC中国船舶', '中建国际', '中远海运', '招商局集团', 'DINBULI',
  'SANY三一重工', '长虹', 'ZGL', 'WEIHUA', '欧柯奇', '建西集团',
  '西鼎', '立中集团', 'KIA', 'XCMG徐工', 'ANSTEEL', '中国华能集团',
  '天润曲轴', '东风汽车', '长城汽车', '华翔集团', '波音', '空中客车',
  '丰田汽车', '中国中车', '上海电气', '中信集团', '北方重工', '长江润发',
]

const cases = [
  { client: '某新能源汽车企业', industry: '新能源汽车', product: 'BHR500V五轴复合加工中心', result: '生产效率提升40%，加工精度达到微米级' },
  { client: '某航空航天企业', industry: '航空航天', product: 'BHR800V大型复合加工中心', result: '实现复杂零件一次装夹完成全部加工' },
  { client: '某模具制造企业', industry: '模具制造', product: 'T-V855S立式加工中心', result: '模具加工周期缩短30%，表面质量显著提升' },
  { client: '某船舶制造企业', industry: '船舶制造', product: 'BHR700V复合加工中心', result: '大型曲轴加工效率提升50%' },
  { client: '某3C电子企业', industry: '3C消费电子', product: 'T-500U五轴钻铣中心', result: '手机金属外壳加工精度达到0.005mm' },
  { client: '某风电企业', industry: '新能源', product: 'BL20-HSY车铣中心', result: '风电齿轮箱零件加工效率翻倍' },
]

export default function Cases() {
  return (
    <div>
      <PageHeader 
        title="客户案例" 
        subtitle="与众多知名企业建立长期合作关系，共同推动智能制造发展"
        breadcrumbs={['首页', '客户案例']}
      />

      {/* Case Studies */}
      <section className="py-20 lg:py-28">
        <div className="section-container">
          <AnimatedSection className="text-center mb-16">
            <div className="text-sm text-primary-600 font-semibold mb-2">CASE STUDIES</div>
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">成功案例</h2>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cases.map((item, index) => (
              <AnimatedSection key={index} delay={index * 0.1}>
                <div className="bg-white rounded-2xl border border-gray-100 hover:border-primary-200 hover:shadow-xl transition-all p-8 h-full">
                  <div className="text-xs text-primary-600 font-semibold mb-2">{item.industry}</div>
                  <h3 className="text-lg font-bold mb-3">{item.client}</h3>
                  <div className="space-y-3 mb-4">
                    <div className="text-sm">
                      <span className="text-gray-500">使用产品：</span>
                      <span className="text-gray-700">{item.product}</span>
                    </div>
                    <div className="text-sm">
                      <span className="text-gray-500">应用成果：</span>
                      <span className="text-primary-600 font-medium">{item.result}</span>
                    </div>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Client Logos */}
      <section className="py-20 lg:py-28 bg-gray-50">
        <div className="section-container">
          <AnimatedSection className="text-center mb-16">
            <div className="text-sm text-primary-600 font-semibold mb-2">CLIENTS</div>
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">合作客户</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">携手世界500强企业及行业龙头，共创智能制造美好未来</p>
          </AnimatedSection>

          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-4">
            {clients.map((client, index) => (
              <AnimatedSection key={index} delay={index * 0.03}>
                <div className="aspect-[3/2] bg-white rounded-xl flex items-center justify-center border border-gray-100 hover:border-primary-200 hover:shadow-lg transition-all">
                  <span className="text-gray-400 text-xs font-medium text-center px-2">{client}</span>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
